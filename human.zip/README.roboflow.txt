
Thermal Human - v1 2022-05-05 5:10pm
==============================

This dataset was exported via roboflow.ai on June 9, 2022 at 11:24 AM GMT

It includes 892 images.
Humans are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


